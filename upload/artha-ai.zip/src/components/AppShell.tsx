import React, { useState, useEffect } from 'react';
import { Menu, X, LogOut, Command, ArrowUp, ArrowDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, ViewState } from '../types';
import DashboardView from '../views/DashboardView';
import DocumentsView from '../views/DocumentsView';
import TaxView from '../views/TaxView';
import FinanceView from '../views/FinanceView';
import AssistantView from '../views/AssistantView';
import GoalsView from '../views/GoalsView';
import SettingsView from '../views/SettingsView';
import ReportsView from '../views/ReportsView';
import PortfolioView from '../views/PortfolioView';
import CashflowView from '../views/CashflowView';
import LiabilitiesView from '../views/LiabilitiesView';
import RetirementView from '../views/RetirementView';
import EstateView from '../views/EstateView';
import CommandPalette from './CommandPalette';
import { cn } from '../lib/utils';

interface AppShellProps {
  user: User;
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  onLogout: () => void;
}

const NAV_CATEGORIES = [
  {
    num: '01',
    category: 'OVERVIEW',
    items: [{ id: 'dashboard', label: 'Dashboard' }]
  },
  {
    num: '02',
    category: 'ASSETS & PORTFOLIO',
    items: [
      { id: 'portfolio', label: 'Portfolio Analytics' },
    ]
  },
  {
    num: '03',
    category: 'CASH & LIQUIDITY',
    items: [
      { id: 'cashflow', label: 'Cashflow & Runway' },
      { id: 'liabilities', label: 'Debt Management' }
    ]
  },
  {
    num: '04',
    category: 'STRATEGY & PLANNING',
    items: [
      { id: 'goals', label: 'Goal Simulations' },
      { id: 'retirement', label: 'Retirement & FIRE' }
    ]
  },
  {
    num: '05',
    category: 'TAX & METRICS',
    items: [
      { id: 'finance', label: 'Financial Health' },
      { id: 'tax', label: 'Tax Readiness' },
      { id: 'reports', label: 'Reports & Audits' }
    ]
  },
  {
    num: '06',
    category: 'VAULT & LEGAL',
    items: [
      { id: 'documents', label: 'Document Vault' },
      { id: 'estate', label: 'Estate Planning' }
    ]
  },
  {
    num: '07',
    category: 'ORACLE',
    items: [{ id: 'assistant', label: 'AI Assistant' }]
  }
];

export default function AppShell({ user, currentView, onNavigate, onLogout }: AppShellProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setCmdOpen((open) => !open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  const handleNav = (view: ViewState) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardView onNavigate={onNavigate} />;
      case 'portfolio': return <PortfolioView />;
      case 'cashflow': return <CashflowView />;
      case 'liabilities': return <LiabilitiesView />;
      case 'retirement': return <RetirementView />;
      case 'documents': return <DocumentsView onNavigate={onNavigate} />;
      case 'estate': return <EstateView />;
      case 'tax': return <TaxView />;
      case 'finance': return <FinanceView />;
      case 'goals': return <GoalsView />;
      case 'reports': return <ReportsView />;
      case 'assistant': return <AssistantView />;
      case 'settings': return <SettingsView user={user} onLogout={onLogout} />;
      default: return <DashboardView onNavigate={onNavigate} />;
    }
  };

  const TICKER_ITEMS = [
    { label: 'HEALTH SCORE', value: '70/100', up: true },
    { label: 'INCOME', value: '₹0', up: true },
    { label: 'SAVINGS RATE', value: '0.0%', up: false },
    { label: 'TAX SAVED', value: '₹90,740', up: true },
    { label: 'TAX SCORE', value: '90/100', up: true },
  ];

  return (
    <div className="min-h-screen bg-canvas text-carbon font-sans flex w-full overflow-hidden relative pb-16 lg:pb-24">
      
      <CommandPalette 
        isOpen={cmdOpen} 
        onClose={() => setCmdOpen(false)} 
        onNavigate={handleNav} 
      />

      {/* Desktop Sidebar (Dark Theme) */}
      <aside className="hidden lg:flex w-[260px] flex-col bg-[#111111] text-stone-light relative z-20 shrink-0">
        <div className="pt-12 pb-10 px-8 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <h1 className="font-serif italic text-2xl tracking-tight text-saffron mb-1">Artha AI</h1>
          <p className="text-[9px] font-bold tracking-[0.2em] text-stone uppercase">Wealth Intelligence</p>
        </div>

        <nav className="flex-1 px-8 py-4 space-y-10 overflow-y-auto">
          {NAV_CATEGORIES.map((cat) => (
            <div key={cat.category}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[10px] font-bold text-saffron tracking-wider">{cat.num}</span>
                <span className="text-[9px] font-bold tracking-[0.1em] text-stone uppercase">— {cat.category}</span>
              </div>
              <div className="space-y-2">
                {cat.items.map((item) => {
                  const isActive = currentView === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNav(item.id as ViewState)}
                      className={cn(
                        "w-full text-left py-1 transition-all text-[15px]",
                        isActive 
                          ? "text-white font-medium" 
                          : "text-stone hover:text-stone-light"
                      )}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-8 mt-auto">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onNavigate('settings')}>
            <div className="w-8 h-8 rounded-md bg-saffron text-white flex items-center justify-center font-bold text-sm shrink-0">
              {user.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-white truncate">{user.name}</p>
              <p className="text-[10px] text-stone uppercase tracking-wider truncate">Premium Tier</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Top Bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-canvas/90 backdrop-blur-xl border-b border-carbon/5 z-40 flex items-center justify-between px-6">
        <div className="flex items-center gap-2" onClick={() => onNavigate('dashboard')}>
          <span className="font-serif italic text-xl tracking-tight text-saffron">Artha AI</span>
        </div>
        <button onClick={() => setMobileMenuOpen(true)} className="p-2 -mr-2 rounded-lg text-carbon hover:bg-carbon/5 transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-carbon/20 backdrop-blur-sm z-50 lg:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: "spring", bounce: 0, duration: 0.4 }}
              className="fixed top-0 left-0 bottom-0 w-4/5 max-w-sm bg-[#111111] text-stone-light z-50 p-8 shadow-2xl lg:hidden overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-10">
                <span className="font-serif italic text-2xl tracking-tight text-saffron">Artha AI</span>
                <button 
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 -mr-2 rounded-lg text-stone hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <nav className="space-y-10">
                {NAV_CATEGORIES.map((cat) => (
                  <div key={cat.category}>
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-[10px] font-bold text-saffron tracking-wider">{cat.num}</span>
                      <span className="text-[9px] font-bold tracking-[0.1em] text-stone uppercase">— {cat.category}</span>
                    </div>
                    <div className="space-y-3">
                      {cat.items.map((item) => {
                        const isActive = currentView === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => handleNav(item.id as ViewState)}
                            className={cn(
                              "w-full text-left py-1 transition-all text-lg",
                              isActive ? "text-white font-medium" : "text-stone hover:text-stone-light"
                            )}
                          >
                            {item.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </nav>
              <div className="mt-12 pt-8 border-t border-white/10">
                <button
                  onClick={onLogout}
                  className="w-full flex items-center gap-3 text-base font-medium text-red-500 hover:text-red-400 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Log Out</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="flex-1 relative lg:h-screen lg:overflow-y-auto pt-16 lg:pt-0 bg-canvas flex flex-col">
        {/* Minimal Desktop Header */}
        <div className="hidden lg:flex shrink-0 top-0 z-10 h-20 items-center justify-between px-12 max-w-[1200px] mx-auto w-full">
          <div className="text-[10px] font-bold text-carbon uppercase tracking-[0.2em]">
            Assessment Period: FY 2024-25
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              AI Model Online
            </div>
            <button 
              onClick={() => setCmdOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-carbon text-white rounded-full hover:bg-carbon/90 transition-colors"
            >
              <Command className="w-3.5 h-3.5" />
              <span className="text-[9px] font-bold tracking-widest uppercase">Command</span>
            </button>
          </div>
        </div>

        <div className="flex-1 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="min-h-full"
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Fixed Footer Bar */}
      <div className="fixed bottom-0 left-0 lg:left-[260px] right-0 z-40 bg-gradient-to-t from-[#EFEFE9] via-[#EFEFE9] to-transparent pt-12 pb-6 px-6 lg:px-12 pointer-events-none">
        <div className="flex items-center justify-between mb-4 w-full max-w-[1200px] mx-auto">
          <div /> {/* Spacer */}
          <div className="text-[10px] font-bold text-carbon/50 uppercase tracking-[0.1em] flex items-center gap-2 bg-canvas/80 px-3 py-1 rounded-full backdrop-blur-sm pointer-events-auto shadow-sm">
            <Command className="w-3 h-3" /> Press <span className="font-mono bg-carbon/5 px-1 rounded text-carbon">⌘K</span> for command palette
          </div>
        </div>

        <div className="w-full bg-white rounded-full h-12 shadow-sm border border-carbon/5 overflow-hidden flex items-center relative pointer-events-auto">
          <motion.div
            animate={{ x: [0, -1000] }}
            transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
            className="flex items-center whitespace-nowrap min-w-max"
          >
            {[...TICKER_ITEMS, ...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
              <div key={i} className="flex items-center text-xs px-6 border-r border-carbon/5 last:border-0">
                <span className="font-bold text-stone tracking-[0.15em] uppercase mr-3">{item.label}</span>
                {item.up ? (
                  <ArrowUp className="w-3.5 h-3.5 text-stone-dark mr-1" />
                ) : (
                  <ArrowDown className="w-3.5 h-3.5 text-red-500 mr-1" />
                )}
                <span className="font-mono font-medium text-carbon">{item.value}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
