"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/app-layout";
import ProtectedRoute from "@/components/protected-route";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { goals as goalsApi } from "@/lib/api";
import { formatINR, formatDate } from "@/lib/format";
import type { Goal } from "@/lib/api";
import { Plus, Target, Trash2, TrendingUp } from "lucide-react";

export default function GoalsPage() {
  return <ProtectedRoute><AppLayout><GoalsContent /></AppLayout></ProtectedRoute>;
}
function GoalsContent() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ goal_name: "", target_amount: "", monthly_contribution: "", target_date: "" });
  const { toast } = useToast();

  const load = () => { goalsApi.list().then((r) => { setGoals(r.items); setError(""); }).catch(() => setError("Failed to load goals")).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try { await goalsApi.create({ goal_name: form.goal_name, target_amount: Number(form.target_amount), monthly_contribution: Number(form.monthly_contribution || 0), target_date: form.target_date || undefined, expected_return_rate: 0.04 }); toast({ title: "Goal created!" }); setShowForm(false); setForm({ goal_name: "", target_amount: "", monthly_contribution: "", target_date: "" }); load(); }
    catch (err: any) { toast({ title: "Failed", description: err.detail, variant: "destructive" }); }
  };

  const handleDelete = async (id: string) => {
    try { await fetch(`/api/goals/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${localStorage.getItem("finsight_token")}` } }); toast({ title: "Goal deleted." }); load(); }
    catch { toast({ title: "Delete failed", variant: "destructive" }); }
  };

  if (loading) return <Skeleton className="h-48" />;

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex justify-between items-center"><div><h1 className="text-2xl font-bold text-slate-900 tracking-tight">Goals</h1><p className="text-sm text-slate-400 mt-0.5">Plan and track your financial goals.</p></div><Button onClick={() => setShowForm(!showForm)} className="bg-emerald-500 hover:bg-emerald-600"><Plus className="h-4 w-4 mr-1" />{showForm ? "Cancel" : "New Goal"}</Button></div>
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
      {showForm && (
        <form onSubmit={handleCreate} className="glass rounded-2xl p-6 space-y-3 animate-slide-down">
          <div className="grid md:grid-cols-2 gap-3">
            <div className="space-y-1.5"><label className="text-xs font-medium text-slate-500 uppercase tracking-wider">Goal Name</label><input value={form.goal_name} onChange={(e) => setForm({ ...form, goal_name: e.target.value })} required className="flex h-10 w-full rounded-lg border border-slate-200 bg-white/50 px-3 py-1 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" /></div>
            <div className="space-y-1.5"><label className="text-xs font-medium text-slate-500 uppercase tracking-wider">Target Amount (₹)</label><input type="number" value={form.target_amount} onChange={(e) => setForm({ ...form, target_amount: e.target.value })} required className="flex h-10 w-full rounded-lg border border-slate-200 bg-white/50 px-3 py-1 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" /></div>
            <div className="space-y-1.5"><label className="text-xs font-medium text-slate-500 uppercase tracking-wider">Monthly (₹)</label><input type="number" value={form.monthly_contribution} onChange={(e) => setForm({ ...form, monthly_contribution: e.target.value })} className="flex h-10 w-full rounded-lg border border-slate-200 bg-white/50 px-3 py-1 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" /></div>
            <div className="space-y-1.5"><label className="text-xs font-medium text-slate-500 uppercase tracking-wider">Target Date</label><input type="date" value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} className="flex h-10 w-full rounded-lg border border-slate-200 bg-white/50 px-3 py-1 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" /></div>
          </div>
          <Button type="submit" className="bg-emerald-500 hover:bg-emerald-600">Create Goal</Button>
        </form>
      )}
      {goals.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center"><div className="h-12 w-12 rounded-xl bg-emerald-50 flex items-center justify-center mx-auto mb-3"><Target className="h-6 w-6 text-emerald-500" /></div><p className="text-lg font-medium text-slate-700">No goals yet</p><p className="text-sm text-slate-400 mt-1">Create a goal to start planning your savings.</p><Button className="mt-4 bg-emerald-500 hover:bg-emerald-600" onClick={() => setShowForm(true)}>Create your first goal</Button></div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {goals.map((g, i) => {
            const pct = Math.min(100, (g.current_amount / g.target_amount) * 100);
            return (
              <div key={g.id} className="glass rounded-2xl p-6 card-hover animate-slide-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5"><div className="h-9 w-9 rounded-xl bg-emerald-50 flex items-center justify-center"><Target className="h-4.5 w-4.5 text-emerald-600" /></div><div><h3 className="font-semibold text-slate-900">{g.goal_name}</h3><p className="text-xs text-slate-400">{formatINR(g.target_amount)} target</p></div></div>
                  <div className="flex items-center gap-2"><span className="text-2xl font-bold text-slate-900">{pct.toFixed(0)}%</span><button onClick={() => handleDelete(g.id)} className="text-slate-300 hover:text-red-500 transition-colors p-1"><Trash2 className="h-4 w-4" /></button></div>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden mb-3"><div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full" style={{ width: `${pct}%`, transition: "width 800ms cubic-bezier(0.16,1,0.3,1)" }} /></div>
                <div className="flex justify-between text-xs text-slate-500"><span>{formatINR(g.current_amount)} saved</span>{g.projection?.projected_completion_date && <span>Projected: {formatDate(g.projection.projected_completion_date)}</span>}</div>
                {g.projection?.shortfall > 0 && <div className="mt-2 text-xs text-amber-600 flex items-center gap-1"><TrendingUp className="h-3 w-3" />Shortfall: {formatINR(g.projection.shortfall)}</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
