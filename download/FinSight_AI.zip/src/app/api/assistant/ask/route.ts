import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const { question } = await req.json();
    if (!question) return NextResponse.json({ detail: "Question required" }, { status: 400 });
    const incomes = await db.income.findMany({ where: { userId: payload.sub, verified: true } });
    const expenses = await db.expense.findMany({ where: { userId: payload.sub } });
    const goals = await db.goal.findMany({ where: { userId: payload.sub } });
    const totalIncome = incomes.reduce((s, i) => s + i.amount, 0);
    const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
    const savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome * 100).toFixed(1) : "0";
    const lower = question.toLowerCase();
    let answer = "";
    if (lower.includes("tax") && (lower.includes("score") || lower.includes("low"))) {
      answer = `Your tax readiness score is influenced by document completeness, data verification, and income consistency. Upload your Form 16 and verify all extracted fields. Current income: Rs ${totalIncome.toLocaleString("en-IN")}, savings rate: ${savingsRate}%.`;
    } else if (lower.includes("missing") && lower.includes("document")) {
      answer = `Ensure you have salary slip, Form 16, and bank statement uploaded. These are essential for accurate tax readiness analysis.`;
    } else if (lower.includes("savings") && lower.includes("improve")) {
      answer = `Current savings rate: ${savingsRate}%. Reduce non-essential spending. Aim for at least 20% savings rate.`;
    } else if (lower.includes("spending") || lower.includes("expense")) {
      const catMap: Record<string, number> = {};
      expenses.forEach((e) => { catMap[e.category] = (catMap[e.category] || 0) + e.amount; });
      const top = Object.entries(catMap).sort((a, b) => b[1] - a[1]).slice(0, 3);
      answer = `Total expenses: Rs ${totalExpenses.toLocaleString("en-IN")}. Top categories: ${top.map(([c, a]) => `${c} (Rs ${a.toLocaleString("en-IN")})`).join(", ")}.`;
    } else if (lower.includes("goal")) {
      answer = goals.length > 0 ? `You have ${goals.length} goal(s). First goal: "${goals[0].goalName}" target Rs ${goals[0].targetAmount.toLocaleString("en-IN")}.` : "No goals yet. Create one from the Goals page.";
    } else {
      answer = `I can help with tax readiness, financial health, spending, and goals. Income: Rs ${totalIncome.toLocaleString("en-IN")}, expenses: Rs ${totalExpenses.toLocaleString("en-IN")}.`;
    }
    return NextResponse.json({ answer, sources: ["tax.summary", "finance.metrics"], suggested_followups: [] });
  } catch { return NextResponse.json({ detail: "Failed to process question" }, { status: 500 }); }
}
