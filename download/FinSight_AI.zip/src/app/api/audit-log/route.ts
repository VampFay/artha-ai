import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyToken } from "@/lib/auth";

function safeParse(s: string | null): any { if (!s) return null; try { return JSON.parse(s); } catch { return s; } }

export async function GET(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const logs = await db.auditLog.findMany({ where: { userId: payload.sub }, orderBy: { timestamp: "desc" }, take: 50 });
    return NextResponse.json({ items: logs.map((l) => ({ id: l.id, action: l.action, details: safeParse(l.details), ip_address: l.ipAddress, timestamp: l.timestamp })), total: logs.length, page: 1, size: 50 });
  } catch { return NextResponse.json({ detail: "Failed to fetch audit log" }, { status: 500 }); }
}
