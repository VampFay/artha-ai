import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyToken, verifyPassword } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const user = await db.user.findUnique({ where: { id: payload.sub } });
    if (!user) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ id: user.id, name: user.name, email: user.email, role: user.role, created_at: user.createdAt });
  } catch { return NextResponse.json({ detail: "Failed to fetch user" }, { status: 500 }); }
}

export async function DELETE(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const user = await db.user.findUnique({ where: { id: payload.sub } });
    if (!user) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const body = await req.json();
    if (!(await verifyPassword(body.password, user.passwordHash))) return NextResponse.json({ detail: "Password confirmation failed." }, { status: 401 });
    await db.auditLog.create({ data: { userId: user.id, action: "account_deleted" } });
    await db.user.delete({ where: { id: user.id } });
    return NextResponse.json({ message: "Account deleted." });
  } catch { return NextResponse.json({ detail: "Failed to delete account" }, { status: 500 }); }
}
