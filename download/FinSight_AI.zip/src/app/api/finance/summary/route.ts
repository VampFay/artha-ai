import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import { computeFinanceSummary } from "@/lib/finance-engine";

export async function GET(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const url = new URL(req.url);
    const monthParam = url.searchParams.get("month");
    const ef = parseFloat(url.searchParams.get("emergency_fund") || "0");
    const month = monthParam ? new Date(monthParam) : new Date();
    const summary = await computeFinanceSummary(payload.sub, month, ef);
    return NextResponse.json(summary);
  } catch { return NextResponse.json({ detail: "Failed to compute finance summary" }, { status: 500 }); }
}
