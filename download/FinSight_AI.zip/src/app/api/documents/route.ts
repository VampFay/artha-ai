import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyToken } from "@/lib/auth";
import { createHash } from "crypto";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

const ALLOWED_TYPES = ["salary_slip", "form16", "bank_statement", "rent_receipt", "insurance_receipt", "loan_certificate", "investment_statement", "other"];
const ALLOWED_EXTS = [".pdf", ".jpg", ".jpeg", ".png", ".csv", ".xlsx"];

export async function GET(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const docs = await db.document.findMany({ where: { userId: payload.sub }, orderBy: { createdAt: "desc" } });
    return NextResponse.json({ items: docs.map((d) => ({ id: d.id, document_type: d.documentType, file_name: d.fileName, file_size_bytes: d.fileSizeBytes, mime_type: d.mimeType, processing_status: d.processingStatus, confidence_score: d.confidenceScore, detected_doc_type: d.detectedDocType, created_at: d.createdAt, updated_at: d.updatedAt })), total: docs.length });
  } catch { return NextResponse.json({ detail: "Failed to fetch documents" }, { status: 500 }); }
}

export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });

    const formData = await req.formData();
    const file = formData.get("file") as File;
    const documentType = formData.get("document_type") as string;

    if (!file || !documentType) return NextResponse.json({ detail: "File and document_type required" }, { status: 400 });
    if (!ALLOWED_TYPES.includes(documentType)) return NextResponse.json({ detail: "Invalid document type" }, { status: 400 });
    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTS.includes(ext)) return NextResponse.json({ detail: "File type not supported" }, { status: 400 });
    if (file.size > 10 * 1024 * 1024) return NextResponse.json({ detail: "File too large (max 10MB)" }, { status: 413 });

    const buffer = Buffer.from(await file.arrayBuffer());
    const fileHash = createHash("sha256").update(buffer).digest("hex");

    // Dedup check
    const existing = await db.document.findFirst({ where: { userId: payload.sub, fileHash } });
    if (existing) return NextResponse.json({ detail: "This file has already been uploaded." }, { status: 409 });

    // Save file
    const uploadDir = path.join(process.cwd(), "public", "uploads", payload.sub);
    await mkdir(uploadDir, { recursive: true });
    const docId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const filePath = path.join(uploadDir, `${docId}${ext}`);
    await writeFile(filePath, buffer);

    // Create DB record
    const doc = await db.document.create({
      data: {
        userId: payload.sub,
        documentType,
        fileName: file.name,
        filePath: `/uploads/${payload.sub}/${docId}${ext}`,
        fileHash,
        fileSizeBytes: file.size,
        mimeType: file.type || "application/octet-stream",
        processingStatus: "pending",
      },
    });

    // Simulate async processing — detect type from filename keywords
    const lowerName = file.name.toLowerCase();
    let detectedType = documentType;
    if (lowerName.includes("form") && lowerName.includes("16")) detectedType = "form16";
    else if (lowerName.includes("salary") || lowerName.includes("payslip")) detectedType = "salary_slip";
    else if (lowerName.includes("bank") || lowerName.includes("statement")) detectedType = "bank_statement";

    await db.document.update({ where: { id: doc.id }, data: { processingStatus: "extracted", detectedDocType: detectedType, confidenceScore: 0.9 } });
    await db.auditLog.create({ data: { userId: payload.sub, action: "document_uploaded", details: JSON.stringify({ document_id: doc.id, document_type: documentType }) } });

    return NextResponse.json({ id: doc.id, document_type: doc.documentType, file_name: doc.fileName, file_size_bytes: doc.fileSizeBytes, mime_type: doc.mimeType, processing_status: "extracted", confidence_score: 0.9, detected_doc_type: detectedType, created_at: doc.createdAt, updated_at: doc.updatedAt }, { status: 201 });
  } catch (e) { return NextResponse.json({ detail: "Failed to upload document" }, { status: 500 }); }
}

export async function DELETE(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization");
    if (!auth?.startsWith("Bearer ")) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });
    const payload = await verifyToken(auth.slice(7));
    if (!payload) return NextResponse.json({ detail: "Unauthorized" }, { status: 401 });

    const docs = await db.document.findMany({ where: { userId: payload.sub } });
    for (const d of docs) {
      const fullPath = path.join(process.cwd(), "public", d.filePath);
      try { await writeFile(fullPath, ""); } catch {}
    }
    await db.document.deleteMany({ where: { userId: payload.sub } });
    await db.auditLog.create({ data: { userId: payload.sub, action: "documents_all_deleted", details: JSON.stringify({ count: docs.length }) } });
    return NextResponse.json({ message: `Deleted ${docs.length} document(s).` });
  } catch { return NextResponse.json({ detail: "Failed to delete documents" }, { status: 500 }); }
}
