import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { db } from "./db";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || (process.env.NODE_ENV === "production"
    ? (() => { throw new Error("JWT_SECRET env var is required in production"); })()
    : "dev-secret-change-me-in-prod-9f3a7c2e1b8d4a5f6e9c0b3a7d2e1f8a")
);

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hashed: string): Promise<boolean> {
  return bcrypt.compare(plain, hashed);
}

export async function createToken(userId: string): Promise<string> {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<{ sub: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    // Check if token has been revoked
    const revoked = await db.revokedToken.findUnique({ where: { token } });
    if (revoked) return null;
    return payload as { sub: string };
  } catch {
    return null;
  }
}

export async function revokeToken(token: string, userId?: string): Promise<void> {
  try {
    await db.revokedToken.create({ data: { token, userId } });
  } catch {
    // Token may already be revoked — ignore
  }
}

export const CONSENT_TEXT =
  "FinSight AI needs your permission to process uploaded financial documents for tax-readiness and financial-health analysis. You can delete your documents at any time.";
